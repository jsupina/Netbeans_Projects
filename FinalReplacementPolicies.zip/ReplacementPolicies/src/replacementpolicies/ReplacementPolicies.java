/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package replacementpolicies;

import java.util.Random;

/**
 *
 * @author jsupi
 */
public class ReplacementPolicies
{

    public static void main(String[] args)
    {
        System.out.println("Note that all tests are ran with 50 random integers");
        System.out.println("Between 1 and 5, 1 and 5 included. All tests were ran");
        System.out.println("100 times each to obtain the averages");
        System.out.println();
        
        runProgram();
    }
    
    public static void runProgram()
    {
        System.out.println("==================================");
        
        for(int frames = 2; frames <= 5; frames++)
        {
            double fifoTotalFaults = 0;
            double fifoTotalSuccessRate = 0;
            double fifoTotalFailRate = 0;
            double lruTotalFaults = 0;
            double lruTotalSuccessRate = 0;
            double lruTotalFailRate = 0;
            double mruTotalFaults = 0;
            double mruTotalSuccessRate = 0;
            double mruTotalFailRate = 0;
            
            for(int counter = 0; counter < 100; counter++)
            {
                int[] randomNums = randomArray(50, 5);
                FifoQueue fifo = new FifoQueue(randomNums, frames);
                LruQueue lru = new LruQueue(randomNums, frames);
                UdpQueue udp = new UdpQueue(randomNums, frames);
                
                fifoTotalFaults += fifo.getFaultNum();
                fifoTotalSuccessRate += fifo.getSuccessRate();
                fifoTotalFailRate += fifo.getFailRate();
                        
                lruTotalFaults += lru.getFaultNum();
                lruTotalSuccessRate += lru.getSuccessRate();
                lruTotalFailRate += lru.getFailRate();
                
                mruTotalFaults += udp.getFaultNum();
                mruTotalSuccessRate += udp.getSuccessRate();
                mruTotalFailRate += udp.getFailRate();
                
            }
            
            System.out.println("FIFO results for " + frames + " page frames");
            System.out.printf("Average faults per run: %.2f%n", (fifoTotalFaults/100));
            System.out.printf("Average success rate per run: %.2f%n", (fifoTotalSuccessRate/100));
            System.out.printf("Average fail rate per run: %.2f%n", (fifoTotalFailRate/100));
            System.out.println();
            
            System.out.println("LRU results for " + frames + " page frames");
            System.out.printf("Average faults per run: %.2f%n", (lruTotalFaults/100));
            System.out.printf("Average success rate per run: %.2f%n", (lruTotalSuccessRate/100));
            System.out.printf("Average fail rate per run: %.2f%n", (lruTotalFailRate/100));
            System.out.println();
            
            System.out.println("UDP results for " + frames + " page frames");
            System.out.printf("Average faults per run: %.2f%n", (mruTotalFaults/100));
            System.out.printf("Average success rate per run: %.2f%n", (mruTotalSuccessRate/100));
            System.out.printf("Average fail rate per run: %.2f%n", (mruTotalFailRate/100));
            System.out.println();
            
            System.out.println("==================================");
            System.out.println();
        }
    }
    
    
    public static int[] randomArray(int ints,int range)
    {
        Random rand = new Random();
        int[] randomIntegers = new int[ints];
        //System.out.println("Array of random integers");
        
        for(int i = 0;i < randomIntegers.length; i++)
        {
            randomIntegers[i] = rand.nextInt(range);
            //System.out.println(randomIntegers[i]);
        }
        
        return randomIntegers;
    }
    
}
