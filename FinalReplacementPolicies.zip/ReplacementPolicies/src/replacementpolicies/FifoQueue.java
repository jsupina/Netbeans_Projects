/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package replacementpolicies;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author jsupi
 */
public class FifoQueue
{
    private double faultNum = 0.0;
    private double failRate;
    private double successRate;    
    private int pageFrames;
    private int[] randomNums;  
    
    public FifoQueue(int[] randomNums, int pageFrames)
    {
        this.pageFrames = pageFrames;
        this.randomNums = randomNums; 
        processQueueNumbers();
    }
    
    private void processQueueNumbers()
    {
        Queue<Integer> queue = new LinkedList<Integer>();

        double successNum;
        double failPercent;        
        
        for(int counter = 0; counter < 50 ; counter++)
        {
            //if the random integer isn't in queue and the queue size is less than the defined limit, add to the list
            if((!queue.contains(randomNums[counter]))&&(queue.size() < pageFrames))
            {
                queue.add(randomNums[counter]);
                //ystem.out.println("Adding " + randomNums[counter] + " Queue size =" + queue.size());
                faultNum++;
            }
            else if((!queue.contains(randomNums[counter]))&&(queue.size() == pageFrames))
            {
                //System.out.println("Removing: " + queue.poll() + " adding " + randomNums[counter]);
                queue.remove();
                queue.add(randomNums.length);
                faultNum++;
            }
            else
            {
                //System.out.println(randomNums[counter] + " already in memory");
            }           
        }
        
        successNum = 50 - faultNum;
        
        failRate = faultNum/50.0;
        successRate = successNum/50.0;
    }

    public double getFaultNum() {
        return faultNum;
    }

    public double getFailRate() {
        return failRate;
    }

    public double getSuccessRate() {
        return successRate;
    }
}
