/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package replacementpolicies;

import java.util.LinkedList;

/**
 *
 * @author jsupi
 */
public class UdpQueue 
{
    private double faultNum = 0.0;
    private double failRate;
    private double successRate;    
    private int pageFrames;
    private int[] randomNums;  
    
    public UdpQueue(int[] randomNums, int pageFrames)
    {
        this.pageFrames = pageFrames;
        this.randomNums = randomNums; 
        processQueueNumbers();
    }
    
    private void processQueueNumbers()
    {
        LinkedList<Integer> list = new LinkedList<Integer>();
        
        double successNum;
        double failPercent;
        
        for(int counter = 0; counter < 50; counter++)
        {
            if(counter == 49)
            {
                if((!list.contains(randomNums[counter]))&&(list.size() == pageFrames))
                {
                    //System.out.println("Removing: " + queue.poll() + " adding " + randomNums[counter]);
                    list.removeLast();
                    list.addFirst(randomNums[counter]);
                    faultNum++;
                }   
            }
            
            else
            {
                if((!list.contains(randomNums[counter])) && (list.size() < pageFrames))
                {
                    list.addFirst(randomNums[counter]);
                    faultNum++;
                }
            
                else if((!list.contains(randomNums[counter]))&&(list.size() == pageFrames))
                {
                    if(randomNums[counter + 1] == list.getLast())
                    {
                        list.removeFirst();
                        list.addFirst(randomNums[counter]);
                    }    
                    
                    else
                    {
                        list.removeLast();
                        list.addFirst(randomNums[counter]);                       
                    }
                    
                    faultNum++;
                }  
            }                      
        }
        
        successNum = 50 - faultNum;
        
        failRate = faultNum/50.0;
        successRate = successNum/50.0;       
    }

    public double getFaultNum() 
    {
        return faultNum;
    }

    public double getFailRate()
    {
        return failRate;
    }

    public double getSuccessRate()
    {
        return successRate;
    }
}